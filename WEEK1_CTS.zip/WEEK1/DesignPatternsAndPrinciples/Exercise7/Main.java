public class Main {
    public static void main(String[] args) {
        // Create a stock market instance
        StockMarket stockMarket = new StockMarket("TechCorp");

        // Create observer instances
        Observer mobileApp = new MobileApp();
        Observer webApp = new WebApp();

        // Register observers
        stockMarket.registerObserver(mobileApp);
        stockMarket.registerObserver(webApp);

        // Change stock price and notify observers
        stockMarket.setStockPrice(150.75);

        // Deregister an observer and change stock price again
        stockMarket.deregisterObserver(webApp);
        stockMarket.setStockPrice(155.50);
    }
}