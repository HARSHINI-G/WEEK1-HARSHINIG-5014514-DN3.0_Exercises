public class Main {
    public static void main(String[] args) {
        // Create receiver
        Light light = new Light();

        // Create command objects
        Command lightOn = new LightOnCommand(light);
        Command lightOff = new LightOffCommand(light);

        // Create invoker and set commands
        RemoteControl remote = new RemoteControl();
        
        remote.setCommand(lightOn);
        remote.pressButton(); // Light is ON
        
        remote.setCommand(lightOff);
        remote.pressButton(); // Light is OFF
    }
}