public class FinancialForecasting {

    public static double calculateFutureValue(double presentValue, double rate, int years) {
        // Base case: if years is 0, the future value is just the present value
        if (years == 0) {
            return presentValue;
        }

        return calculateFutureValue(presentValue * (1 + rate), rate, years - 1);
    }

    public static void main(String[] args) {
        double presentValue = 1000.0; // Initial amount
        double rate = 0.05;           // 5% annual growth rate
        int years = 10;               // Number of years to forecast

        double futureValue = calculateFutureValue(presentValue, rate, years);
        System.out.printf("The future value after %d years is: %.2f%n", years, futureValue);
    }
}