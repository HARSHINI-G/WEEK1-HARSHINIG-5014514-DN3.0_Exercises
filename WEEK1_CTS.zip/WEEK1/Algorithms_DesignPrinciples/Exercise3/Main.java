public class Main {
    public static void main(String[] args) {
        // Create an array of orders
        Order[] orders = {
            new Order(1, "Alice", 150.00),
            new Order(2, "Bob", 200.00),
            new Order(3, "Charlie", 100.00),
            new Order(4, "Diana", 300.00)
        };

        // Clone orders array for each sort
        Order[] bubbleSortOrders = orders.clone();
        Order[] quickSortOrders = orders.clone();

        // Apply Bubble Sort
        SortingUtils.bubbleSort(bubbleSortOrders);
        System.out.println("Bubble Sorted Orders:");
        for (Order order : bubbleSortOrders) {
            System.out.println(order);
        }

        // Apply Quick Sort
        SortingUtils.quickSort(quickSortOrders, 0, quickSortOrders.length - 1);
        System.out.println("Quick Sorted Orders:");
        for (Order order : quickSortOrders) {
            System.out.println(order);
        }
    }
}