public class Main {
    public static void main(String[] args) {
        InventoryManager inventoryManager = new InventoryManager();

        // Create some products
        Product product1 = new Product(1, "Laptop", 50, 999.99);
        Product product2 = new Product(2, "Smartphone", 100, 499.99);

        // Add products to inventory
        inventoryManager.addProduct(product1);
        inventoryManager.addProduct(product2);

        // Display inventory
        System.out.println("Inventory:");
        inventoryManager.displayInventory();

        // Update a product
        Product updatedProduct1 = new Product(1, "Laptop", 45, 949.99);
        inventoryManager.updateProduct(updatedProduct1);

        // Display updated inventory
        System.out.println("Updated Inventory:");
        inventoryManager.displayInventory();

        // Delete a product
        inventoryManager.deleteProduct(2);

        // Display inventory after deletion
        System.out.println("Inventory after deletion:");
        inventoryManager.displayInventory();
    }
}